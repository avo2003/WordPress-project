<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'avo' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'ae|TLT`DeAbEOits%ps1 gosmX((BwblK;:hENMvu6gS5>t#tY`yhY[y 1w%QuQJ' );
define( 'SECURE_AUTH_KEY',  'Ai[|xG/!22^3q6/Otmj]Fqw5t%Btw-o98JaS3DI&-Al:mkTD_$I&}O7)&GteBsbp' );
define( 'LOGGED_IN_KEY',    'TxMJK:~<m$>/,ue#]$Zq3NwW@K0<]^/p,m6wxpRpqNa?(i=$]H,dPT0?UI>Jjv@[' );
define( 'NONCE_KEY',        'n3Y$N^SifrB,M^j?(~|Xx^hoi<WRtu#YB!F)rb+u~T]8@Gq`b#}kH4j3]5p<0:gG' );
define( 'AUTH_SALT',        'MdRYdLtJYB>kFkc+l<8B4${1Uj5]0,qoB2m-9(*,9I}WT`T&dvy.43?l7t]jl>f9' );
define( 'SECURE_AUTH_SALT', ';I3E[PX?+Fir8w5b2@#F9Q;&pK;5U_]!vP^9]T&3&B~n`MV^5u ~|2-%R^%wM&S~' );
define( 'LOGGED_IN_SALT',   'Y$ZPzj7gf`u;j`nCuITE/3q0yX5Z0Sim{QH$OE9*$_6;!xo4:KE.bhm?a_kaE.;w' );
define( 'NONCE_SALT',       'lin5ik+}S!tw&)oy ~ud1.5rnY}j.c,aeUS0 ,>tajn.>4VP!BOw=/bk/Bm3S*kr' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
